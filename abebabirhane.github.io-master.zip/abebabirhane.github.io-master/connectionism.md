---
permalink: connectionism
---
